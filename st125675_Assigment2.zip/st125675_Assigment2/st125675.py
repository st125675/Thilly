import streamlit as st
import pandas as pd

st.title("My First Streamlit App")#Heading
st.write("Hello, world!")#Displaying content

#User Input Widgets

#Text Field
name = st.text_input("Enter your name:")#User Input field

# Slider
age = st.slider("Select your age:", 0, 100, 25)  # Min, Max, Default

# Selectbox
city = st.selectbox("Select your city:", ["London", "Paris", "Tokyo"])

# Checkbox
show_data = st.checkbox("Show data")
#df = pd.DataFrame(data)

# Sample Data (replace with your own)
#data = {'Name': ['Alice', 'Bob', 'Charlie'], 'Age': [25, 30, 22]}
data={'name':[name],'age':[age],'city':[city]}#Here the value in this dictionary is a list.
df = pd.DataFrame(data)

if show_data:#Checking whether the check box is clicked
    st.dataframe(df)


if st.button("Click me"):  # The argument is the button's label
    if name !="":
        st.write(f"Hello, {name}!, you are {age} years old and you live in {city}") #This is the conditional part. It checks if the variable name has a valuest.write(f"Age: {age}")
        if show_data:#Checking whether the check box is clicked
            st.dataframe(df)

    else:
        st.warning('Enter Your Name')


    